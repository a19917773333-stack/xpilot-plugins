"""ARS408 configuration and motion frames, ported from sunnypilot.

These encoders are the transmit half of the C3's radar package: RadarConfiguration (0x200), FilterCfg (0x300),
SpeedInformation (0x300) and YawRateInformation (0x301) on bus 1. This plugin only builds the frames; nothing
here sends one. Sending needs can.tx claims plus panda runtime rules in the host repository (XPILOT.md section 2
and 6), which is a host change and lands before this file is wired into the radar interface.
"""
import math

from opendbc.can import CANPacker
from opendbc.car import structs
from opendbc.car.can_definitions import CanData

from .constants import ARS408_BUS, ARS408_DBC, FILTER_SIGNAL_SPECS

MOTION_TX_INTERVAL_FRAMES = 5
MAX_SPEED_MPS = 85.0
MAX_ABS_YAW_RATE_DEG_S = 100.0


class ARS408Transmitter:
  """Builds the radar's configuration and motion frames; enabled is the plugin's ARS408 backend."""

  def __init__(self, enabled: bool) -> None:
    self.enabled = bool(enabled)
    self.packer = CANPacker(ARS408_DBC)

  def encode_radar_configuration(self, field: str, value: int | bool) -> CanData:
    values: dict[str, int] = {}
    if field == "max_distance":
      distance = int(value)
      if distance < 200 or distance > 250 or distance % 2:
        raise ValueError("ARS408 maximum distance must be even and within 200..250 m")
      values = {"RadarCfg_MaxDistance_valid": 1, "RadarCfg_MaxDistance": distance}
    elif field == "send_extended":
      enabled = self._binary(value, field)
      values = {"RadarCfg_SendExtInfo_valid": 1, "RadarCfg_SendExtInfo": enabled}
    elif field == "output_type":
      output_type = int(value)
      if output_type not in (0, 1):
        raise ValueError("ARS408 output type must be disabled or Objects")
      values = {"RadarCfg_OutputType_valid": 1, "RadarCfg_OutputType": output_type}
    else:
      raise ValueError(f"unsupported ARS408 configuration field: {field}")
    return self.packer.make_can_msg("RadarConfiguration", ARS408_BUS, values)

  def encode_filter_configuration(self, index: int, active: bool, minimum: float, maximum: float) -> CanData:
    if index not in FILTER_SIGNAL_SPECS:
      raise ValueError(f"unsupported ARS408 filter index: {index}")
    active_value = self._binary(active, "active")
    minimum, maximum = float(minimum), float(maximum)
    if not math.isfinite(minimum) or not math.isfinite(maximum):
      raise ValueError("ARS408 filter bounds must be finite")
    spec = FILTER_SIGNAL_SPECS[index]
    if index == 0:
      minimum = 0.0
    if not (spec.lower <= minimum <= maximum <= spec.upper):
      raise ValueError(f"invalid ARS408 filter range: {minimum}..{maximum}")
    raw_min = self._filter_raw(minimum, spec.resolution, spec.offset, spec.bits)
    raw_max = self._filter_raw(maximum, spec.resolution, spec.offset, spec.bits)
    return self.packer.make_can_msg("FilterCfg", ARS408_BUS, {
      "FilterCfg_Type": 1, "FilterCfg_Index": index, "FilterCfg_Active": active_value,
      "FilterCfg_Valid": 1, "FilterCfg_MinRaw": raw_min, "FilterCfg_MaxRaw": raw_max,
    })

  def encode_filter_query(self, index: int) -> CanData:
    if index not in FILTER_SIGNAL_SPECS:
      raise ValueError(f"unsupported ARS408 filter index: {index}")
    return self.packer.make_can_msg("FilterCfg", ARS408_BUS, {
      "FilterCfg_Type": 1, "FilterCfg_Index": index, "FilterCfg_Active": 0, "FilterCfg_Valid": 0,
    })

  def encode_speed(self, speed_mps: float, direction: int) -> CanData:
    speed_mps = float(speed_mps)
    if not math.isfinite(speed_mps) or not 0.0 <= speed_mps <= MAX_SPEED_MPS:
      raise ValueError(f"ARS408 speed is outside 0..{MAX_SPEED_MPS} m/s")
    if direction not in (0, 1, 2):
      raise ValueError("ARS408 speed direction must be standstill, forward, or reverse")
    return self.packer.make_can_msg("SpeedInformation", ARS408_BUS, {
      "RadarDevice_SpeedDirection": direction, "RadarDevice_Speed": speed_mps,
    })

  def encode_yaw_rate(self, yaw_rate_deg_s: float) -> CanData:
    yaw_rate_deg_s = float(yaw_rate_deg_s)
    if not math.isfinite(yaw_rate_deg_s) or abs(yaw_rate_deg_s) > MAX_ABS_YAW_RATE_DEG_S:
      raise ValueError(f"ARS408 yaw rate is outside +/-{MAX_ABS_YAW_RATE_DEG_S} deg/s")
    return self.packer.make_can_msg("YawRateInformation", ARS408_BUS, {"RadarDevice_YawRate": yaw_rate_deg_s})

  def update(self, frame: int, car_state: structs.CarState) -> list[CanData]:
    if not self.enabled or frame < 0 or frame % MOTION_TX_INTERVAL_FRAMES or not car_state.canValid:
      return []
    speed_mps = abs(float(car_state.vEgoRaw))
    if car_state.standstill or speed_mps <= 0.01:
      direction = 0
    elif car_state.gearShifter == structs.CarState.GearShifter.reverse:
      direction = 2
    else:
      direction = 1
    try:
      return [self.encode_speed(speed_mps, direction), self.encode_yaw_rate(-math.degrees(float(car_state.yawRate)))]
    except ValueError:
      return []

  @staticmethod
  def _binary(value: int | bool, field: str) -> int:
    converted = int(value)
    if converted not in (0, 1):
      raise ValueError(f"ARS408 {field} must be 0 or 1")
    return converted

  @staticmethod
  def _filter_raw(value: float, resolution: float, offset: float, bits: int) -> int:
    raw = round((value - offset) / resolution)
    if not 0 <= raw < 1 << bits:
      raise ValueError("ARS408 filter value is not representable")
    decoded = raw * resolution + offset
    if abs(decoded - value) > resolution / 2.0 + 1e-9:
      raise ValueError("ARS408 filter value loses excessive precision")
    return raw